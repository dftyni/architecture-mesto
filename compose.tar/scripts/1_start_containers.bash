#!/bin/bash


# Запускаем mongodb и приложения

docker compose up -d
